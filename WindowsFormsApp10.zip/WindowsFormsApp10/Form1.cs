﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp10
{
	public partial class Form1 : Form
	{
		private DataGridViewColumn dataGridViewColumn1 = null;
		private DataGridViewColumn dataGridViewColumn2 = null;
		private DataGridViewColumn dataGridViewColumn3 = null;
		private DataGridViewColumn dataGridViewColumn4 = null;
		private DataGridViewColumn dataGridViewColumn5 = null;

		private SortedDictionary<Computer, Computer> PC = new SortedDictionary<Computer, Computer>();

		public Form1()
		{
			InitializeComponent();
			initDataGridView();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			try
			{
				if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "")
				{
					MessageBox.Show("Введите все поля", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
				}
				else
				{
					string choose = "";
					if (char.IsSymbol(textBox1.Text[0]) || char.IsPunctuation(textBox1.Text[0]))
					{
                        MessageBox.Show("В поле производителя ПК не должно быть символов, знаков", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        textBox1.Text = "";
                        return;
                    }
					if (char.IsSymbol(textBox2.Text[0]) || char.IsPunctuation(textBox2.Text[0]))
					{
                        MessageBox.Show("В поле видеокарта не должно быть знаков пунктуации или символов", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        textBox2.Text = "";
                        return;
                    }
					if (char.IsSymbol(textBox3.Text[0]))
					{
                        MessageBox.Show("В поле материнской платы не должны быть символы", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        textBox3.Text = "";
                        return;
                    }
					if (char.IsLetter(textBox4.Text[0]) || char.IsPunctuation(textBox4.Text[0]) || char.IsSymbol(textBox4.Text[0]))
					{
						MessageBox.Show("В поле оперативной памяти не должно быть букв, символов, знаков", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
						textBox4.Text = "";
						return;
					}
					if (radioButton1.Checked)
					{
						choose = radioButton1.Text;
					}
					else if (radioButton2.Checked)
					{
						choose = radioButton2.Text;
					}
					else
					{
						MessageBox.Show("Вы не выбрали процессор!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
						return;
					}
					addPC(textBox1.Text, choose, textBox3.Text, Convert.ToInt32(textBox4.Text), textBox2.Text);
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show($"В ходе работы, произошла ошибка: {ex.Message}");
			}
		}

		private DataGridViewColumn GetDataGridViewColumn1()
		{
			if (dataGridViewColumn1 == null)
			{
				dataGridViewColumn1 = new DataGridViewTextBoxColumn();
				dataGridViewColumn1.Name = "";
				dataGridViewColumn1.HeaderText = "Производитель ПК";
				dataGridViewColumn1.ValueType = typeof(string);
				dataGridViewColumn1.Width = dataGridView1.Width / 5;
			}
			return dataGridViewColumn1;
		}

		private DataGridViewColumn GetDataGridViewColumn2()
		{
			if (dataGridViewColumn2 == null)
			{
				dataGridViewColumn2 = new DataGridViewTextBoxColumn();
				dataGridViewColumn2.Name = "";
				dataGridViewColumn2.HeaderText = "Процессор";
				dataGridViewColumn2.ValueType = typeof(string);
				dataGridViewColumn2.Width = dataGridView1.Width / 5;
			}
			return dataGridViewColumn2;
		}

		private DataGridViewColumn GetDataGridViewColumn3()
		{
			if (dataGridViewColumn3 == null)
			{
				dataGridViewColumn3 = new DataGridViewTextBoxColumn();
				dataGridViewColumn3.Name = "";
				dataGridViewColumn3.HeaderText = "Материнская плата";
				dataGridViewColumn3.ValueType = typeof(string);
				dataGridViewColumn3.Width = dataGridView1.Width / 5;
			}
			return dataGridViewColumn3;
		}

		private DataGridViewColumn GetDataGridViewColumn4()
		{
			if (dataGridViewColumn4 == null)
			{
				dataGridViewColumn4 = new DataGridViewTextBoxColumn();
				dataGridViewColumn4.Name = "";
				dataGridViewColumn4.HeaderText = "Оперативная память";
				dataGridViewColumn4.ValueType = typeof(int);
				dataGridViewColumn4.Width = dataGridView1.Width / 5;
			}
			return dataGridViewColumn4;
		}

		private DataGridViewColumn GetDataGridViewColumn5()
		{
			if (dataGridViewColumn5 == null)
			{
				dataGridViewColumn5 = new DataGridViewTextBoxColumn();
				dataGridViewColumn5.Name = "";
				dataGridViewColumn5.HeaderText = "Видеокарта";
				dataGridViewColumn5.ValueType = typeof(string);
				dataGridViewColumn5.Width = dataGridView1.Width / 5;
			}
			return dataGridViewColumn5;
		}

		private void addPC(string companyPC, string processor, string videocard, int memory, string motherboard)
		{
			Computer computer = new Computer(companyPC, processor, videocard, memory, motherboard);
			PC.Add(computer, (Computer)(computer as object));
			showListInGrid();
		}

		private void initDataGridView()
		{
			dataGridView1.DataSource = null;
			dataGridView1.Columns.Add(GetDataGridViewColumn1());
			dataGridView1.Columns.Add(GetDataGridViewColumn2());
			dataGridView1.Columns.Add(GetDataGridViewColumn3());
			dataGridView1.Columns.Add(GetDataGridViewColumn4());
			dataGridView1.Columns.Add(GetDataGridViewColumn5());
			dataGridView1.AutoResizeColumns();
		}

		private void showListInGrid()
		{
			dataGridView1.Rows.Clear();
			foreach (Computer c in PC.Keys)
			{
				DataGridViewRow row = new DataGridViewRow();
				DataGridViewTextBoxCell cell1 = new DataGridViewTextBoxCell();
				DataGridViewTextBoxCell cell2 = new DataGridViewTextBoxCell();
				DataGridViewTextBoxCell cell3 = new DataGridViewTextBoxCell();
				DataGridViewTextBoxCell cell4 = new DataGridViewTextBoxCell();
				DataGridViewTextBoxCell cell5 = new DataGridViewTextBoxCell();


				cell1.Value = c.Name();
				cell2.Value = c.Processor_Name();
				cell3.Value = c.VideoCard();
				cell4.Value = c.RAM();
				cell5.Value = c.Mother();
				row.Cells.Add(cell1);
				row.Cells.Add(cell2);
				row.Cells.Add(cell3);
				row.Cells.Add(cell4);
				row.Cells.Add(cell5);

				dataGridView1.Rows.Add(row);

			}
		}

		private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
		{

		}

		private void удалитьToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
                if (dataGridView1.SelectedRows.Count > 0)
                {
                    int selectedRowIndex = dataGridView1.SelectedRows[0].Index;
                    PC.Remove(PC.ElementAt(selectedRowIndex).Key);
                    dataGridView1.Rows.RemoveAt(selectedRowIndex);
                }
            }
			catch
			{
				MessageBox.Show("Нельзя удалить пустое поле в таблице");
				return;
			}
			
		}

        private void поискToolStripMenuItem_Click(object sender, EventArgs e)
        {
			MessageBox.Show("Чтобы можно было выполнить поиск, нужно написать в первое поле название производителя ПК","Справка");
            int count = 0;

            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                foreach (DataGridViewCell cell in row.Cells)
                {
                    if (cell.Value != null && cell.Value.ToString().Contains(textBox1.Text))
                    {
                        count++;
                    }
                }
            }
			if (count == 0)
			{
                MessageBox.Show($"Не найдено элементов, содержащих {textBox1.Text}");
            }
			else
			{
                MessageBox.Show($"Найдены элементы, содержащих {textBox1.Text}: {count}.");
            }
        }

        private void количествоToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int rowCount = dataGridView1.Rows.Count;
			int columnCount = dataGridView1.Columns.Count;
            int cellCount = dataGridView1.Rows.Cast<DataGridViewRow>().Sum(row => row.Cells.Count);
            MessageBox.Show($"Количество строк в таблице: {rowCount}\nКоличество столбцов в таблице: {columnCount}\nКоличество ячеек в таблицe: {cellCount}");
        }
    }
}
