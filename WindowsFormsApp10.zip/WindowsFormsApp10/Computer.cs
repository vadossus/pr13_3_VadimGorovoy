﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp10
{
	class Computer: IComparable<Computer>
    {
		public string NameCompanyPC;

		public string Processor;

		public string Videocard;

		public int MemoryRAM;

		public string Motherboard;

		public Computer(string companyPC, string processor, string videocard, int memory, string motherboard)
        {
			NameCompanyPC = companyPC;
			Processor = processor;
			Videocard = videocard;
			MemoryRAM = memory;
			Motherboard = motherboard;
        }

		public string Name()
		{
			return NameCompanyPC;
		}

		public string Processor_Name()
		{
			return Processor;
		}

		public string VideoCard()
		{
			return Videocard;
		}

		public int RAM()
		{
			return MemoryRAM;
		}

		public string Mother()
		{
			return Motherboard;
		}

        public int CompareTo(Computer other)
        {
            int result = NameCompanyPC.CompareTo(other.NameCompanyPC);
            if (result == 0)
            {
                result = Processor.CompareTo(other.Processor);
            }
            if (result == 0)
            {
                result = Videocard.CompareTo(other.Videocard);
            }
            if (result == 0)
            {
                result = MemoryRAM.CompareTo(other.MemoryRAM);
            }
            if (result == 0)
            {
                result = Motherboard.CompareTo(other.Motherboard);
            }
            return result;
        }
    }
}
